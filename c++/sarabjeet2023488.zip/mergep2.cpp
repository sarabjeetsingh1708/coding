#include <iostream>
#include <vector>

using namespace std;

vector<int> mergesort(const vector<int>& arr) {
    int n = arr.size();
    int index = 3;

    
    vector<int> firsthalf(arr.begin(), arr.begin() + index);
    vector<int> secondhalf(arr.begin() + index, arr.end());

    
    int i = 0, j = 0, k = 0;
    vector<int> final(n);

    
    while (i < firsthalf.size() && j < secondhalf.size()) {
        if (firsthalf[i] < secondhalf[j]) {
            final[k] = firsthalf[i];
            i++;
        } else {
            final[k] = secondhalf[j];
            j++;
        }
        k++;
    }

   
    while (i < firsthalf.size()) {
        final[k] = firsthalf[i];
        i++;
        k++;
    }

    while (j < secondhalf.size()) {
        final[k] = secondhalf[j];
        j++;
        k++;
    }

    return final;
}

int main() {
    vector<int> array = {8,9,10,1,2,3,4,5,6,7};
    vector<int> output = mergesort(array);
    int n = array.size();
    
   for(int i=0; i<n; i++){
        cout<<output[i]<<"  "; 
    }
    

    return 0;
}
